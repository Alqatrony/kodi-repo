#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
from urllib.request import Request, urlopen

__addon__ = xbmcaddon.Addon()
__scriptid__ = __addon__.getAddonInfo('id')

HEALTH_URL = "https://subdlbridge-api.onrender.com/health"

# How often to ping the server (seconds). Render free tier sleeps after
# ~15 min of inactivity, so we ping more frequently to keep it awake.
PING_INTERVAL = 600  # 10 minutes


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(u"### [%s][warmup] - %s" % (__scriptid__, msg), level)


def ping():
    try:
        req = Request(HEALTH_URL, headers={'User-Agent': 'SubdlBridge-Kodi'})
        with urlopen(req, timeout=120) as res:
            res.read()
        log("Warm-up ping OK")
        return True
    except Exception as e:
        log("Warm-up ping failed: %s" % str(e), xbmc.LOGWARNING)
        return False


if __name__ == '__main__':
    monitor = xbmc.Monitor()
    log("Service started, sending initial warm-up ping")
    ping()

    while not monitor.abortRequested():
        # Wait for the interval, but wake up immediately if Kodi is shutting down
        if monitor.waitForAbort(PING_INTERVAL):
            break
        ping()

    log("Service stopped")
